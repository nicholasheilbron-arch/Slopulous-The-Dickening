#pragma once
#include "CoreMinimal.h"
#include "ShamanTypes.generated.h"

UENUM(BlueprintType)
enum class EHitTier : uint8 { None, Stagger, Knockdown, Ragdoll, Launch };

UENUM(BlueprintType)
enum class ESpellTargeting : uint8 { Projectile, Ground, Self, Area };

UENUM(BlueprintType)
enum class EMonumentType : uint8 { VaultOfKnowledge, StoneHead, Obelisk, Gargoyle };

UENUM(BlueprintType)
enum class EWorshipRule : uint8 { ShamanOnly, ShamanAndBraves };

UENUM(BlueprintType)
enum class EMonumentRewardType : uint8 { UnlockSpell, UnlockBuilding, GrantCharges, WorldEvent };
