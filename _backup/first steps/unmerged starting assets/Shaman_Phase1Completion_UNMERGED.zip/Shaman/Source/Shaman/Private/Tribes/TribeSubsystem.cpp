#include "Tribes/TribeSubsystem.h"
#include "Characters/ShamanUnitBase.h"
#include "Buildings/BuildingActor.h"
#include "SpellComponent.h"
#include "Core/ShamanLog.h"
#include "Engine/World.h"
#include "TimerManager.h"

void UTribeSubsystem::InitTribes(const TArray<FTribeDefinition>& Definitions, const FReincarnationConfig& InRebirth)
{
	Tribes.Reset();
	Rebirth = InRebirth;
	for (int32 I = 0; I < Definitions.Num(); ++I)
	{
		FTribeState& T = Tribes.AddDefaulted_GetRef();
		T.TribeId = I;
		T.Def = Definitions[I];
	}
}

void UTribeSubsystem::Prune(FTribeState& T) const
{
	T.Followers.RemoveAll([](const TWeakObjectPtr<AShamanUnitBase>& U) { return !U.IsValid() || !U->IsAlive(); });
	T.Buildings.RemoveAll([](const TWeakObjectPtr<ABuildingActor>& B) { return !B.IsValid(); });
}

void UTribeSubsystem::FollowersChanged(FTribeState& T)
{
	Prune(T);
	const int32 Count = T.Followers.Num();
	// Mana regen is driven by follower count (spec section 6): push it to the tribe's Shaman.
	if (AShamanUnitBase* S = T.Shaman.Get())
		if (USpellComponent* Spells = S->FindComponentByClass<USpellComponent>())
			Spells->FollowerCount = Count;
	OnFollowersChanged.Broadcast(T.TribeId, Count);
}

void UTribeSubsystem::RegisterUnit(AShamanUnitBase* Unit)
{
	if (!Unit) return;
	FTribeState* T = Find(Unit->GetTribeId());
	if (!T) return; // Wildmen and unaligned units are not tribe members
	if (Unit->IsShaman())
	{
		T->Shaman = Unit;
	}
	else if (Unit->CountsAsFollower())
	{
		T->Followers.AddUnique(Unit);
	}
	FollowersChanged(*T);
}

void UTribeSubsystem::UnregisterUnit(AShamanUnitBase* Unit)
{
	if (!Unit) return;
	for (FTribeState& T : Tribes) // search all: the unit may already have changed tribe
	{
		const int32 Removed = T.Followers.Remove(Unit);
		if (Removed > 0) FollowersChanged(T);
	}
}

void UTribeSubsystem::RegisterBuilding(ABuildingActor* B)
{
	if (!B) return;
	FTribeState* T = Find(B->GetTribeId());
	if (!T) return;
	T->Buildings.AddUnique(B);
	if (B->IsReincarnationSite()) T->Circle = B;
}

void UTribeSubsystem::UnregisterBuilding(ABuildingActor* B)
{
	for (FTribeState& T : Tribes)
	{
		T.Buildings.Remove(B);
		if (T.Circle.Get() == B) T.Circle = nullptr;
	}
}

int32 UTribeSubsystem::GetFollowerCount(int32 TribeId) const
{
	const FTribeState* T = Find(TribeId);
	if (!T) return 0;
	int32 N = 0;
	for (const TWeakObjectPtr<AShamanUnitBase>& U : T->Followers) if (U.IsValid() && U->IsAlive()) ++N;
	return N;
}

int32 UTribeSubsystem::GetPopulationCapacity(int32 TribeId) const
{
	const FTribeState* T = Find(TribeId);
	if (!T) return 0;
	int32 Cap = T->Def.BaseCapacity;
	for (const TWeakObjectPtr<ABuildingActor>& B : T->Buildings) if (B.IsValid()) Cap += B->GetPopulationCapacity();
	return Cap;
}

AShamanUnitBase* UTribeSubsystem::GetShaman(int32 TribeId) const
{
	const FTribeState* T = Find(TribeId);
	return T ? T->Shaman.Get() : nullptr;
}

ABuildingActor* UTribeSubsystem::GetReincarnationCircle(int32 TribeId) const
{
	const FTribeState* T = Find(TribeId);
	return T ? T->Circle.Get() : nullptr;
}

FLinearColor UTribeSubsystem::GetTribeColor(int32 TribeId) const
{
	const FTribeState* T = Find(TribeId);
	return T ? T->Def.Color : FLinearColor::White;
}

float UTribeSubsystem::GetRebirthRemaining(int32 TribeId) const
{
	const FTribeState* T = Find(TribeId);
	if (!T || T->RebirthAt < 0.0) return -1.f;
	return FMath::Max(0.f, (float)(T->RebirthAt - GetWorld()->GetTimeSeconds()));
}

TArray<AShamanUnitBase*> UTribeSubsystem::GetFollowers(int32 TribeId) const
{
	TArray<AShamanUnitBase*> Out;
	if (const FTribeState* T = Find(TribeId))
		for (const TWeakObjectPtr<AShamanUnitBase>& U : T->Followers)
			if (U.IsValid() && U->IsAlive()) Out.Add(U.Get());
	return Out;
}

float UTribeSubsystem::ComputeRebirthTime(const FReincarnationConfig& C, int32 Followers)
{
	const float Modifier = 1.f + FMath::Max(0.f, C.PerFollowerModifier) * FMath::Max(0, Followers);
	return FMath::Clamp(C.BaseTime / Modifier, C.MinTime, FMath::Max(C.MinTime, C.MaxTime));
}

void UTribeSubsystem::NotifyShamanDied(AShamanUnitBase* Shaman)
{
	FTribeState* T = Shaman ? Find(Shaman->GetTribeId()) : nullptr;
	if (!T) return;
	OnShamanDied.Broadcast(T->TribeId, Shaman);

	const bool bMayReincarnate = T->Def.bPlayerControlled || Rebirth.bEnemyShamansReincarnate;
	if (!T->Circle.IsValid() || !bMayReincarnate)
	{
		T->bShamanEliminated = true; // Phase 4: tribe defeat / Shaman-kill reward hooks go here
		UE_LOG(LogShaman, Log, TEXT("Shaman of tribe %d permanently eliminated."), T->TribeId);
		return;
	}
	const float Delay = ComputeRebirthTime(Rebirth, GetFollowerCount(T->TribeId));
	T->RebirthAt = GetWorld()->GetTimeSeconds() + Delay;
	FTimerDelegate D = FTimerDelegate::CreateUObject(this, &UTribeSubsystem::DoRebirth, T->TribeId);
	GetWorld()->GetTimerManager().SetTimer(T->RebirthTimer, D, Delay, false);
	UE_LOG(LogShaman, Log, TEXT("Shaman of tribe %d reborn in %.1fs."), T->TribeId, Delay);
}

void UTribeSubsystem::DoRebirth(int32 TribeId)
{
	FTribeState* T = Find(TribeId);
	if (!T) return;
	T->RebirthAt = -1.0;
	AShamanUnitBase* S = T->Shaman.Get();
	ABuildingActor* C = T->Circle.Get();
	if (!S || !C) { T->bShamanEliminated = true; return; }
	S->Reincarnate(C->GetRebirthLocation(), C->GetActorRotation());
	FollowersChanged(*T);
	OnShamanReborn.Broadcast(TribeId, S);
}
