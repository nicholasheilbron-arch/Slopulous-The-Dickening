#include "SpellComponent.h"
#include "SpellProjectile.h"
#include "Engine/DataTable.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Pawn.h"
#include "Engine/World.h"
#include "Sound/SoundBase.h"
#include "Kismet/GameplayStatics.h"

USpellComponent::USpellComponent() { PrimaryComponentTick.bCanEverTick = true; PrimaryComponentTick.TickInterval = 0.1f; }

float USpellComponent::GetManaRegen() const
{
	return BaseRegen * (1.f + RegenPerFollower * FollowerCount) * TemporaryModifier;
}

void USpellComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* F)
{
	Super::TickComponent(DeltaTime, TickType, F);
	Mana = FMath::Min(MaxMana, Mana + GetManaRegen() * DeltaTime);
}

void USpellComponent::LearnSpell(FName SpellId) { KnownSpellIds.AddUnique(SpellId); }

void USpellComponent::AddCharges(FName SpellId, int32 Charges)
{
	if (Charges <= 0) return;
	KnownSpellIds.AddUnique(SpellId);
	SpellCharges.FindOrAdd(SpellId) += Charges;
}

float USpellComponent::GetRangeUnits(FName SpellId) const
{
	const FSpellRow* Row = SpellTable ? SpellTable->FindRow<FSpellRow>(SpellId, TEXT("GetRangeUnits")) : nullptr;
	return Row ? Row->RangeRaw * RangeUnitsPerPoint : 0.f;
}

bool USpellComponent::CastSpell(FName SpellId, FVector AimTarget)
{
	if (!SpellTable || !KnownSpellIds.Contains(SpellId)) return false;
	const FSpellRow* Row = SpellTable->FindRow<FSpellRow>(SpellId, TEXT("CastSpell"));
	if (!Row) return false;

	const double Now = GetWorld()->GetTimeSeconds();
	if (const double* End = CooldownEnd.Find(SpellId)) { if (Now < *End) return false; }
	const float Cost = Row->bSuperSpell ? 0.f : Row->ManaCost;
	if (Mana < Cost) return false;
	if (Row->bSuperSpell && GetCharges(SpellId) <= 0) return false;

	AActor* Owner = GetOwner();
	const float RangeUU = Row->RangeRaw * RangeUnitsPerPoint;
	if (Row->Targeting != ESpellTargeting::Self && RangeUU > 0.f && Row->Targeting != ESpellTargeting::Projectile
		&& FVector::Dist(Owner->GetActorLocation(), AimTarget) > RangeUU) return false; // out of range

	Mana -= Cost;
	CooldownEnd.Add(SpellId, Now + Row->Cooldown);
	if (USoundBase* Snd = Row->CastSound.LoadSynchronous()) UGameplayStatics::PlaySoundAtLocation(this, Snd, Owner->GetActorLocation());

	if (Row->Targeting == ESpellTargeting::Projectile)
	{
		if (const TSubclassOf<ASpellProjectile>* Cls = ProjectileClasses.Find(Row->EffectId))
		{
			const FVector Start = Owner->GetActorLocation() + Owner->GetActorForwardVector() * 100.f + FVector(0, 0, 60);
			FActorSpawnParameters P; P.Instigator = Cast<APawn>(Owner); P.Owner = Owner;
			if (ASpellProjectile* Proj = GetWorld()->SpawnActor<ASpellProjectile>(*Cls, Start, (AimTarget - Start).Rotation(), P))
				Proj->Init(*Row, RangeUU);
		}
	}
	else
	{
		OnSpellCast.Broadcast(SpellId, Row->EffectId, AimTarget, Row->Radius, Row->Duration);
	}

	if (Row->bSuperSpell && --SpellCharges.FindOrAdd(SpellId) <= 0) { SpellCharges.Remove(SpellId); KnownSpellIds.Remove(SpellId); }
	return true;
}
