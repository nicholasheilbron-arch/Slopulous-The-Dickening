#pragma once
#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ShamanTypes.h"
#include "RagdollReactionComponent.generated.h"

class UHitReactionConfig;

/** Put on any ACharacter. Turns (damage, direction) into stagger / ragdoll / launch. */
UCLASS(ClassGroup=(Shaman), meta=(BlueprintSpawnableComponent))
class SHAMAN_API URagdollReactionComponent : public UActorComponent
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly) UHitReactionConfig* Config = nullptr;

	UFUNCTION(BlueprintCallable) void ApplyHit(float Damage, FVector Direction);
	UFUNCTION(BlueprintCallable) bool IsRagdolling() const { return bRagdolling; }

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnHitReaction, EHitTier, Tier, float, Damage);
	UPROPERTY(BlueprintAssignable) FOnHitReaction OnHitReaction;

private:
	void StartRagdoll(const FVector& Impulse);
	void EndRagdoll();
	bool bRagdolling = false;
	FTimerHandle RecoverTimer;
};
