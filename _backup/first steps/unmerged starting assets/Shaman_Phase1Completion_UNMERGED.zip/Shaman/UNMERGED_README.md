# Phase 1 completion work: paused, not merged

This tree was built before the PM narrowed the scope to the Convert milestone. It is **not** part of the Convert delivery.
It adds deterministic seeded world generation, a terrain mesh, water, data-driven units/buildings/resources, a tribe subsystem
with reincarnation, a simple AI, a canvas HUD and UE4 project/config files. It is uncompiled.
Its tribe system overlaps with the Convert milestone's TribeComponent/TribeRegistrySubsystem; if adopted, it should be
reconciled onto the Convert classes rather than kept as a second tribe system.

Verified: the world generator (Tools/WorldGenHarness) compiles and passes 3,000 seeds standalone.

Known issues from code review, not yet fixed:
1. Terrain triangle winding probably faces down (set AShamanTerrainActor::bFlipWinding = true by default).
2. Player Shaman spawns an unused AI controller (set AutoPossessAI = Disabled before FinishSpawning).
3. Death launch is cancelled by DisableMovement (MOVE_None) on placeholder units.
4. ShamanRegenerate leaves old rebirth timers running (clear them in InitTribes).
5. Ragdoll collision profile is not restored on recovery (existing RagdollReactionComponent behaviour).
6. Missing unit row makes the Shaman register as a follower.
7. Projectile with range 0 never expires; Blast fizzles silently at max range (existing behaviour, not changed).
8. Homing ignores target rules (existing behaviour, not changed).
