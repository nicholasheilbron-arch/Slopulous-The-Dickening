#include "RagdollReactionComponent.h"
#include "HitReactionConfig.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/CapsuleComponent.h"
#include "TimerManager.h"

void URagdollReactionComponent::ApplyHit(float Damage, FVector Direction)
{
	if (!Config || bRagdolling) return;
	const EHitTier Tier = Config->GetTier(Damage);
	if (Tier == EHitTier::None) return;
	OnHitReaction.Broadcast(Tier, Damage);

	ACharacter* Char = Cast<ACharacter>(GetOwner());
	if (!Char) return;

	Direction = (Direction.GetSafeNormal() + FVector::UpVector * Config->UpwardBias).GetSafeNormal();
	const FVector Impulse = Direction * Config->BaseImpulse * Config->DamageMultiplier * (Damage / Config->RagdollMinDamage);

	switch (Tier)
	{
	case EHitTier::Stagger:
		Char->LaunchCharacter(Direction * 200.f, true, false);
		break;
	case EHitTier::Knockdown:
		StartRagdoll(Impulse * 0.25f);
		break;
	default: // Ragdoll + Launch: distance scales with damage via Impulse
		StartRagdoll(Impulse);
		break;
	}
}

void URagdollReactionComponent::StartRagdoll(const FVector& Impulse)
{
	ACharacter* Char = Cast<ACharacter>(GetOwner());
	if (!Char || !Char->GetMesh()) return;
	bRagdolling = true;
	Char->GetCharacterMovement()->DisableMovement();
	Char->GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Char->GetMesh()->SetCollisionProfileName(TEXT("Ragdoll"));
	Char->GetMesh()->SetSimulatePhysics(true);
	Char->GetMesh()->AddImpulse(Impulse, NAME_None, true);
	GetWorld()->GetTimerManager().SetTimer(RecoverTimer, this, &URagdollReactionComponent::EndRagdoll, Config->RagdollRecoverTime, false);
}

void URagdollReactionComponent::EndRagdoll()
{
	ACharacter* Char = Cast<ACharacter>(GetOwner());
	if (!Char) return;
	const float HalfHeight = Char->GetCapsuleComponent()->GetScaledCapsuleHalfHeight();
	const FVector Landed = Char->GetMesh()->GetComponentLocation() + FVector(0, 0, HalfHeight);
	Char->GetMesh()->SetSimulatePhysics(false);
	Char->GetMesh()->AttachToComponent(Char->GetCapsuleComponent(), FAttachmentTransformRules::SnapToTargetNotIncludingScale);
	Char->GetMesh()->SetRelativeLocationAndRotation(FVector(0, 0, -HalfHeight), FRotator(0, -90, 0));
	Char->SetActorLocation(Landed, false, nullptr, ETeleportType::TeleportPhysics);
	Char->GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	Char->GetCharacterMovement()->SetMovementMode(MOVE_Walking);
	bRagdolling = false;
}
