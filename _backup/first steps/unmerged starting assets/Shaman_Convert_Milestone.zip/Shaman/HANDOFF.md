# SHAMAN: handoff notes

Paste this file into the new chat along with the original design spec (not included in this zip) and the zip contents.

## Project
Single-player, third-person fantasy god-game inspired mechanically by Populous: The Beginning. The player is the Shaman; the tribe supports the Shaman. Claude acts as lead gameplay programmer under a human project manager and must not redesign core mechanics unprompted. Priorities: fun over realism, systemic gameplay over visual detail, accessibility over complexity. Build systems, not features; everything data-driven; save system designed early; stop and report after each milestone and wait for PM confirmation.

## Decisions made so far
- Engine: **Unreal Engine 4** (C++ core, Blueprints for content). Code is uncompiled; expect small first-build fixes.
- **Blast is the same spell as Taka**: the first-level tracking (homing) fire blast.
- All 19 listed spells added (16 regular + Armageddon, Teleport, Bloodlust). The source list said 20 but named 19.
- Spell range and mana keep the original 0-100 scales. World units = RangeRaw * RangeUnitsPerPoint (default 50).
- Super spells cost no mana and run on **charges** (granted by Stone Heads).
- Worshippable monuments follow the PM's screenshot, which supersedes the original spec's "Obelisk/Shrine" split:
  - Vault of Knowledge: Shaman only; permanent new spell or building plan; carries to future maps (replaces the spec's "Shrine")
  - Stone Head: Shaman or Braves; generates charges of a specific spell; sinks when depleted (this is what the spec called "Obelisk")
  - Obelisk: Shaman only; segments spin 90 degrees; triggers world events or unique rewards (open paths, alter landscape, teleport Shaman)
  - Gargoyle: rare Angel-of-Death-shaped Stone Head; only the Shaman charges it, followers still play the animation; grants a game-winning effect (five Angels of Death kill the enemy Shaman)

## Implemented (Source/Shaman)
- `SpellRow.h`, `SpellComponent`, `SpellProjectile`: data-table-driven spells, mana regen = BaseRegen * (1 + RegenPerFollower * followers) * TemporaryModifier, cooldowns, charges, homing projectile, `OnSpellCast` event for non-projectile effects.
- `HitReactionConfig`, `RagdollReactionComponent`: damage -> stagger / knockdown / ragdoll / launch; impulse = BaseImpulse * DamageMultiplier * Direction.
- `MonumentRow`, `MonumentActor`, `ProgressionComponent`: monument archetypes in a data table; reward chosen per placed instance; progression state is save-ready.
- Data: `Content/Data/Spells.csv`, `Content/Data/Monuments.csv` (import as DataTables with FSpellRow / FMonumentRow).

## Setup
1. Add the `Shaman` C++ module to the UE4 project.
2. Import the two CSVs as DataTables.
3. Blueprint child of `ASpellProjectile` for Blast; register it in the SpellComponent's `ProjectileClasses` under `FireBlast`.
4. Create a `HitReactionConfig` asset; assign it to enemies' `RagdollReactionComponent`. Add a `Ragdoll` collision profile.
5. Shaman character: `SpellComponent` (+ `ProgressionComponent`), learn `Blast`, call `CastSpell("Blast", AimPoint)`.

## Stubs / not done
- No effect handlers yet for the 18 non-projectile spells (they spend mana and fire `OnSpellCast` only).
- No world-event system (Obelisk/Gargoyle `OnWorldEvent`), no building damage/ignite, cast time unused, no health/death system.
- Damage, radius, cooldown, duration, worship times, and unlock conditions in the CSVs are placeholders for the PM to tune.
- Not started: tribe framework (3 Braves, house, campfire, reincarnation circle), procedural world, enemy tribe and Shaman, save system.

## Convert milestone (2026-10-05)
Implemented on top of the Phase 1 slice without touching SpellRow / SpellComponent / SpellProjectile / RagdollReaction / Spells.csv.
- `TribeMemberComponent`: unit identity for targeting/conversion (TribeId, UnitKind = Follower/Wildman/Shaman/Building/Other, bConvertible, PopulationCost) + `CanBeConvertedTo` / `ConvertToTribe` / `SetTribeId`. Wildmen use TribeId -1.
- `TribeComponent`: smallest tribe (id, follower roster, PopulationCapacity, `CanAddFollowers`, idempotent `RegisterFollower`, `ConvertedFollowerClass` = BP_Brave hook). Roster is the only source of the count. Pushes follower count to the owner's SpellComponent (mana regen).
- `TribeRegistrySubsystem` (world subsystem): tribe id -> tribe, all unit identities, `GetMembersInRadius` (no collision channels), any BeginPlay order.
- `SpellEffect` (abstract, instanced) + `SpellEffectDispatcherComponent`: listens to the unchanged `OnSpellCast`, routes `EffectId` to an effect object. Ships `SpellEffect_ConvertUnits` bound to `ConvertWildmen` (EConversionKind::Recruit). Plays the row's ImpactVFX/ImpactSound if assigned.
- `EConversionKind::Permanent` / `Hypnotize` exist as API but return "not convertible" until their milestones.
- `Private/Shaman.cpp` (module implementation) added; it was missing from the archive.
- Tests: `Private/Tests/ConvertSpellTests.cpp` (11 automation tests, `Shaman.Spells.Convert.*`, editor context). Logic harness: `Tools/ConvertHarness/build.sh` (runs the real tribe/convert .cpp files against a small shim; 55 checks).

### Editor setup for Convert
1. BP_Shaman: add `TribeComponent` (TribeId 0, PopulationCapacity, ConvertedFollowerClass = BP_Brave when it exists) and `SpellEffectDispatcherComponent`; `LearnSpell("Convert")` (or add to KnownSpellIds).
2. BP_Wildman: add `TribeMemberComponent` (UnitKind Wildman, TribeId -1).
3. BP_Brave: add `TribeMemberComponent` (UnitKind Follower). Placed Braves: set TribeId 0.
4. Enemy Shaman/followers: TribeComponent TribeId 1 on the enemy Shaman; their followers TribeId 1.
5. Tribe ids must be unique per world; a duplicate is ignored with a warning.
With no ConvertedFollowerClass, Wildmen convert in place (identity changes, actor stays); bind `OnConverted` for a visual swap.

## Suggested next steps
Invisibility (Phase 3 order: Convert, Invisibility, Magical Shield, Land Bridge, Swarm, Lightning) as a second USpellEffect subclass, after the PM confirms Convert in the editor.
