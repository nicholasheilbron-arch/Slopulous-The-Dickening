#include "Modules/ModuleManager.h"

// Primary game module. (Was missing from the Phase 1 handoff; required for the module to build.)
IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, Shaman, "Shaman");
