#pragma once
#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Tribes/TribeTypes.h"
#include "TribeSubsystem.generated.h"

class AShamanUnitBase;
class ABuildingActor;

/** Runtime state of one tribe. Player and enemy tribes use exactly the same structure. */
struct FTribeState
{
	int32 TribeId = -1;
	FTribeDefinition Def;
	TWeakObjectPtr<AShamanUnitBase> Shaman;
	TArray<TWeakObjectPtr<AShamanUnitBase>> Followers;   // living units that count as followers
	TArray<TWeakObjectPtr<ABuildingActor>> Buildings;
	TWeakObjectPtr<ABuildingActor> Circle;
	double RebirthAt = -1.0;                              // world time of pending rebirth, -1 = none
	bool bShamanEliminated = false;
	FTimerHandle RebirthTimer;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnShamanEvent, int32, TribeId, AShamanUnitBase*, Shaman);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnFollowersChanged, int32, TribeId, int32, FollowerCount);

/**
 * Tribe registry for the world: membership, follower counts (which drive mana regen), population capacity,
 * and reincarnation. Units and buildings register themselves in BeginPlay; nothing else keeps lists of them.
 */
UCLASS()
class SHAMAN_API UTribeSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()
public:
	void InitTribes(const TArray<FTribeDefinition>& Definitions, const FReincarnationConfig& InRebirth);

	void RegisterUnit(AShamanUnitBase* Unit);
	void UnregisterUnit(AShamanUnitBase* Unit);
	void RegisterBuilding(ABuildingActor* Building);
	void UnregisterBuilding(ABuildingActor* Building);

	UFUNCTION(BlueprintCallable) int32 GetFollowerCount(int32 TribeId) const;
	UFUNCTION(BlueprintCallable) int32 GetPopulationCapacity(int32 TribeId) const;
	UFUNCTION(BlueprintCallable) AShamanUnitBase* GetShaman(int32 TribeId) const;
	UFUNCTION(BlueprintCallable) ABuildingActor* GetReincarnationCircle(int32 TribeId) const;
	UFUNCTION(BlueprintCallable) FLinearColor GetTribeColor(int32 TribeId) const;
	/** Seconds until the tribe's Shaman is reborn, or -1 if not dead. */
	UFUNCTION(BlueprintCallable) float GetRebirthRemaining(int32 TribeId) const;
	TArray<AShamanUnitBase*> GetFollowers(int32 TribeId) const;
	int32 GetNumTribes() const { return Tribes.Num(); }

	/** Called by a Shaman when it dies. Starts the rebirth timer if the tribe still has a circle. */
	void NotifyShamanDied(AShamanUnitBase* Shaman);

	static float ComputeRebirthTime(const FReincarnationConfig& Config, int32 Followers);

	UPROPERTY(BlueprintAssignable) FOnShamanEvent OnShamanDied;
	UPROPERTY(BlueprintAssignable) FOnShamanEvent OnShamanReborn;
	UPROPERTY(BlueprintAssignable) FOnFollowersChanged OnFollowersChanged;

private:
	FTribeState* Find(int32 TribeId) { return Tribes.IsValidIndex(TribeId) ? &Tribes[TribeId] : nullptr; }
	const FTribeState* Find(int32 TribeId) const { return Tribes.IsValidIndex(TribeId) ? &Tribes[TribeId] : nullptr; }
	void Prune(FTribeState& T) const;
	void FollowersChanged(FTribeState& T);
	void DoRebirth(int32 TribeId);

	TArray<FTribeState> Tribes;
	FReincarnationConfig Rebirth;
};
